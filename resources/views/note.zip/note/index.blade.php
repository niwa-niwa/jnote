@extends('layouts.mainbase')

@section('title','note')
{{-- @section('subtitle','直近のノート') --}}

@section('header')
@endsection

@section('side_main')
@endsection

@section('main_content')
<div class="list_parent">
    <div class="center">
        <div class="list_top">
            <div class="list_top_child">
                <a href="/note/create/"><i class="far fa-edit note-menu" title="New Note"></i></a>
            </div>
            <div class="list_top_child">
                <a href="/note/trash/"><i class="far fa-trash-alt note-menu" title="ゴミ箱を見る"></i></a>
            </div>
        </div>

        <div class="list_middle">
            @isset($items[0])
                @foreach ($items as $item)
                    <div class="list_child">
                        @php
                            echo '<a href="/note/index?id=' . $item->id . '" >' . $item->getShortText() . '</a>';
                        @endphp
                    </div>
                @endforeach
            @endisset
        </div>
    </div>
</div>

<div class="article_view">
    <div class="center">
        @isset($items[0])
            @foreach ($items as $item)
                @if($item->id == $req->id)
                <div class="list_top">
                    <a href="/note/update?id={{ $item->id }}">
                        <i class="fas fa-pencil-ruler note-menu" title="Edit"></i>
                    </a>
                </div>
                <div class="main_article">

                    @if(0 !== strlen ($item->textnote))
                        {!! nl2br($item->textnote) !!}
                    @else
                        {!! nl2br($item->text) !!}
                    @endif
                </div>
                    @break;
                @endif
            @endforeach
        @else
            <p>ノートはありません。</p>
        @endisset
    </div>
</div>
@endsection

@section('footer')
@endsection