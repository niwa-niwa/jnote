@extends('layouts.mainbase')

@section('title','note')
@section('subtitle','ゴミ箱')


@section('header')
@endsection

@section('side_main')
@endsection

@section('main_content')
{{-- <a href="/note/create/"><p>ノートを書く</p></a> --}}
<p>ゴミ箱の中身が表示されます。</p>
<p><a href="/note/index/">一覧に戻る</a></p>

{{-- ゴミ箱がからだったときの処理を書く --}}
<div class="list_parent">
    @isset($items[0])
        @foreach ($items as $item)
            <div class="list_child">
                @php
                    echo '<a href="/note/trash?id=' . $item->id . '" >' . $item->getShortText() . '</a>';
                @endphp
            </div>
            <br>
        @endforeach
    @endisset
</div>

<div class="article_view">
    <div>
        @isset($items[0])
            @if(isset($req->id))
                @foreach ($items as $item)
                    @if($item->id == $req->id)
                    <form action="/note/trash" method="post">
                            @csrf
                            <input type="hidden" name="id" value="{{ $item->id }}">
                            <input type="hidden" name="func" value="restore">
                            <button type="submit">ノートを復元</button>
                        </form>
                        <br><br>
                        <form action="/note/trash" method="post">
                            @csrf
                            <input type="hidden" name="id" value="{{ $item->id }}">
                            <input type="hidden" name="func" value="destroy">
                            <button type="submit" >完全に削除</button>
                        </form>
                        <br><br>
                        {!! nl2br($item->text) !!}
                        @break;
                    @endif
                @endforeach
            @else
                <form action="/note/trash" method="post">
                    @csrf
                    <input type="hidden" name="id" value="{{ $items[0]->id }}">
                    <input type="hidden" name="func" value="restore">
                    <button type="submit" >ノート復元</button>
                </form>
                <br><br>
                <form action="/note/trash" method="post">
                    @csrf
                    <input type="hidden" name="id" value="{{ $items[0]->id }}">
                    <input type="hidden" name="func" value="destroy">
                    <button type="submit" >完全に削除</button>
                </form>
                <br><br>
                {!! nl2br($items[0]->text) !!}
            @endif
        @else
                <p>ゴミ箱には何もありません。</p>
        @endisset
    </div>
</div>
@endsection

@section('footer')
@endsection
